About the Author
===

Alex works as a web developer and is currently studying Computer Science at Oregon State University. The purpose of this site is to go over the specifics of AJAX when using the Jquery framework.
