console.log(cutInHalf(10));

function cutInHalf(x) {
    return x / 2;
}

cubed(5);

var cube = function cubed(y){
    return y * y * Y;
}
